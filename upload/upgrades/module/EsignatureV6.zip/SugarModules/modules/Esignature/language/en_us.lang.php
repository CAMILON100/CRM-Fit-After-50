<?php

$mod_strings['LBL_MANAGE_ESIGNATURE'] = "ESignature";
$mod_strings['LBL_ESIGNATURE'] = "ESignature Settings";
$mod_strings['LBL_ESIGNATURE_ENABLE'] = "Enable ESignature";
$mod_strings['LBL_ESIGNATURE_KEY'] = "ESIGNATURE Key";
$mod_strings['LBL_ESIGNATURE_MODULES'] = "Enable Modules";
//$mod_strings['GOOGLE_CLIENT_SECRET'] = "Client Secret";
$mod_strings['LBL_ESIGNATURE_LICENSEADDON'] = "License Configuration";
$mod_strings['LBL_ESIGNATURE_LICENSEADDON_DESCRIPTION'] = "Manage and configure the license for this add-on";
$mod_strings['LBL_ESIGNATURE_FEATURES'] = "Features";