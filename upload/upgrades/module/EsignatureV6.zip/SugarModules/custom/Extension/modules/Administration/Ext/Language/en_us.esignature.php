<?php

/**
 * @Author: Khwaish Nagdev
 * @Date:   2018-07-20 13:27:46
 * @Last Modified by:   Khwaish Nagdev
 * @Last Modified time: 2018-07-20 13:30:57
 */
$mod_strings['LBL_MANAGE_ESIGNATURE'] = "ESignature";
$mod_strings['LBL_ESIGNATURE'] = "ESignature Settings";
$mod_strings['ESIGNATURE_ENABLE'] = "Enable ESignature";
$mod_strings['ESIGNATURE_KEY'] = "Esignature Key";
$mod_strings['ESIGNATURE_MODULES'] = "Enable Modules";
// $mod_strings['GOOGLE_CLIENT_SECRET'] = "Client Secret";
$mod_strings['LBL_ESIGNATURE_LICENSEADDON'] = "License Configuration";
$mod_strings['LBL_ESIGNATURE_LICENSEADDON_DESCRIPTION'] = "Manage and configure the license for this add-on";