<?php
 // created: 2018-12-06 12:14:38
$dictionary['AOS_Contracts']['fields']['contact']['required']=true;
$dictionary['AOS_Contracts']['fields']['contact']['inline_edit']=false;
$dictionary['AOS_Contracts']['fields']['contact']['merge_filter']='disabled';

 ?>
