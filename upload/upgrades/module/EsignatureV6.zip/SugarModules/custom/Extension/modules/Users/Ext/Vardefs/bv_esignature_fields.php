<?php
$dictionary['User']['fields']['user_signature'] = array(
	'name' => 'user_signature',
	'link' => true,
	'vname' => 'LBL_USER_SIGNATURE',
	'labelValue' => 'User Signature',
	'type' => 'varchar',
	'dbType' => 'varchar',
	'len' => 255,
	'required' => false,
	'importable' => 'required',
	'duplicate_merge' => 'disabled',
	'merge_filter' => 'disabled',
	'inline_edit' => true,
	'duplicate_merge_dom_value' => '0',
);
