<?php

$mod_strings['LBL_USER_SIGNATURE'] = 'Signature';
