<?php
$entry_point_registry['setSignature'] = array(
	'file' => 'custom/brainvire/setSignature.php',
	'auth' => false,
);
$entry_point_registry['save_sign'] = array(
	'file' => 'custom/brainvire/save_sign.php',
	'auth' => false,
);
$entry_point_registry['generatePdf'] = array(
	'file' => 'custom/brainvire/AOS_PDF_Templates/generatePdf.php',
	'auth' => false,
);
