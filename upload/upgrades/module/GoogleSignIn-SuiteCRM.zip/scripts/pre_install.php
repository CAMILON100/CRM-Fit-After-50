<?php

	function pre_install() {
	    if(!file_exists('custom/modules/Users/Login.php')) {
			copy('modules/Users/Login.php', 'custom/modules/Users/Login.php');
		}

		$f = fopen("custom/modules/Users/Login.php", "r+");

		$oldstr = file_get_contents("custom/modules/Users/Login.php");
		$str_to_insert = '$google_signin_clientid = $sugar_config["google_signin_clientid"];

echo $AAA = <<<EOQ
	<script src="https://apis.google.com/js/platform.js" async defer></script>
	<script>
		$(document).ready(function(){
			var googleSignInClientId = "$google_signin_clientid";
			if(googleSignInClientId != "") {
				$("head").append("<meta name=\"google-signin-client_id\" content=\""+googleSignInClientId+"\" />");
				$("form").find("input[type=\"submit\"]").after("<div>OR</div><div class=\"g-signin2\" data-width=\"370\" data-height=\"40\" data-longtitle=\"true\" data-onsuccess=\"onSignIn\"></div>");
			}
		});
		function onSignIn(googleUser) {
			var profile = googleUser.getBasicProfile();
			var id_token = googleUser.getAuthResponse().id_token;
			$.ajax({
				type: "POST",
				url: "https://www.googleapis.com/oauth2/v3/tokeninfo",
				contentType: "application/x-www-form-urlencoded",
				data: {"id_token": id_token}
			}).success(function(data) {
				if(data.email.trim() != "") {
					$.ajax({
						type: "POST",
						url: "index.php?entryPoint=PostGoogleSignIn",
						data: { "user_email": data.email}
					}).success(function(data){
						var result = JSON.parse(data);
						if(result.code) {
							window.location.href = result.message;
						} else {
							alert(result.message);
							location.reload(true);
						}
					});
				}
			});
		}
	</script>
EOQ;

';
		$specificLine = "if (file_exists('custom/themes/' . SugarThemeRegistry::current() . '/login.tpl')) {";

		while (($buffer = fgets($f)) !== false) {
			if (strpos($buffer, $specificLine) !== false) {
				$pos = ftell($f); 
				$newstr = substr_replace($oldstr, $str_to_insert, $pos-strlen($specificLine)-1, 0);
				file_put_contents("custom/modules/Users/Login.php", $newstr);
				break;
			}
		}
		fclose($f);
	}

?>