<?php

    $entry_point_registry['PostGoogleSignIn'] = array(
        'file' => 'custom/include/GoogleSignIn/PostGoogleSignInAuthenticate.php',
        'auth' => false
    );
