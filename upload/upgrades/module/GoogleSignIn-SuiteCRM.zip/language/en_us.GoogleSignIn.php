<?php

$mod_strings['LBL_GOOGLE_SIGN_IN_ADMIN'] = 'Google Sign-In';
$mod_strings['LBL_GOOGLE_SIGN_IN_ADMIN_DESCRIPTION'] = 'Enable Google Sign-In';
$mod_strings['LBL_GOOGLE_SIGN_IN_ADMIN_TITLE'] = 'Google Sign-In Configuration';
$mod_strings['GOOGLE_SIGN_IN_ADMIN_TITLE'] = 'Google Sign-In';
$mod_strings['GOOGLE_SIGN_IN_ADMIN_DESC'] = 'Google Sign-In Configuration';
$mod_strings['LBL_GOOGLE_SIGN_IN_ADMIN_CLIENT_ID'] = 'Client ID';
$mod_strings['LBL_GOOGLE_SIGN_IN_ADMIN_CLIENT_SECRET'] = 'Client Secret';
$mod_strings['LBL_GOOGLE_SIGN_IN_ADMIN_MANAGE'] = 'Google Sign-In Configuration';